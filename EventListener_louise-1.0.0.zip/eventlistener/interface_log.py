# interface_log.py
from qgis.PyQt import uic
from qgis.PyQt.QtWidgets import QDockWidget

# charge le fichier .ui placé dans le même dossier
FORM_CLASS, _ = uic.loadUiType(__file__.replace("interface_log.py", "ui_event_listener.ui"))

class LogDock(QDockWidget, FORM_CLASS):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        # s'assurer que le widget a un objet texte nommé logText (QTextEdit)
    def add_line(self, text):
        """Ajoute une ligne horodatée au log et scroll vers la fin."""
        from datetime import datetime
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        existing = self.logText.toPlainText()
        new = f"{ts} — {text}"
        if existing:
            self.logText.setPlainText(existing + "\n" + new)
        else:
            self.logText.setPlainText(new)
        # place le curseur en bas
        self.logText.moveCursor(self.logText.textCursor().End)
