# event_listener.py
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsProject
from qgis.gui import QgsMapToolEmitPoint, QgsMapToolIdentifyFeature
from .interface_log import LogDock
try:
    from . import resources_rc  # si tu as compilé resources.qrc -> resources_rc.py
    USE_ICON = True
except Exception:
    USE_ICON = False

class EventListener:
    def __init__(self, iface):
        """
        iface : QgisInterface fourni par QGIS
        """
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.project = QgsProject.instance()

        self.action = None
        self.dock = None

        # outils pour la carte
        self.point_tool = None
        self.identify_tool = None

        # connexions signal -> slot stockées pour pouvoir déconnecter proprement
        self._layer_selection_connections = {}  # layer.id(): connection id

    def initGui(self):
        """Crée l'UI (bouton + dock) et active l'écoute des événements globaux."""
        # action dans la toolbar
        if USE_ICON:
            icon = QIcon(":/icons/event.png")
            self.action = QAction(icon, "Event Listener", self.iface.mainWindow())
        else:
            self.action = QAction("Event Listener", self.iface.mainWindow())

        self.action.setCheckable(True)
        self.action.toggled.connect(self.toggle_listener)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&EventListener", self.action)

        # créer le dock (fenêtre de log)
        self.dock = LogDock(self.iface.mainWindow())
        self.dock.setObjectName("EventListenerDock")
        self.iface.addDockWidget(2, self.dock)  # 2 ~ Qt.RightDockWidgetArea
        self.dock.hide()

    def toggle_listener(self, checked):
        """Active / désactive l'écoute des événements."""
        if checked:
            self.start_listening()
            self.dock.show()
            self.dock.add_line("Listener activé.")
            # active outil de point par défaut (pour capter clics simple)
            self.activate_point_tool()
        else:
            self.stop_listening()
            self.dock.add_line("Listener désactivé.")
            self.dock.hide()

    # --------------------
    # Outils carte (clics / identification)
    # --------------------
    def activate_point_tool(self):
        """Outil simple pour obtenir les coordonnées du clic."""
        if self.point_tool is None:
            self.point_tool = QgsMapToolEmitPoint(self.canvas)
            self.point_tool.canvasClicked.connect(self.on_map_clicked)
        self.canvas.setMapTool(self.point_tool)
        self.dock.add_line("Outil de point activé (clic -> coordonnées).")

    def activate_identify_tool(self):
        """Outil pour identifier une entité (feature) sous le clic."""
        if self.identify_tool is None:
            self.identify_tool = QgsMapToolIdentifyFeature(self.canvas)
            # featureIdentified fournit la feature
            try:
                self.identify_tool.featureIdentified.connect(self.on_feature_identified)
            except Exception:
                # selon version QGIS, le nom du signal peut différer ; prévenir pédagogiquement
                pass
        self.canvas.setMapTool(self.identify_tool)
        self.dock.add_line("Outil d'identification activé (clic -> feature).")

    def on_map_clicked(self, point, button=None):
        """Slot appelé quand l'utilisateur clique sur la carte (QgsPointXY)."""
        # point est un QgsPointXY ; on logge les coordonnées
        self.dock.add_line(f"Clic carte : x={point.x():.6f}, y={point.y():.6f}")
    def on_extent_changed(self):
        """Log lorsque la carte change d'emprise (zoom, pan, rotation)."""
        try:
            extent = self.canvas.extent()
            self.dock.add_line(
                f"Navigation carte : emprise changée -> "
                f"xmin={extent.xMinimum():.2f}, ymin={extent.yMinimum():.2f}, "
                f"xmax={extent.xMaximum():.2f}, ymax={extent.yMaximum():.2f}"
            )
        except Exception as e:
            self.dock.add_line(f"Erreur extentsChanged : {e}")

    def on_feature_identified(self, feature):
        """Slot appelé quand une feature est identifiée par l'outil identify."""
        try:
            fid = feature.id()
            layer = feature.layer()
            layer_name = layer.name() if layer is not None else "?"
            self.dock.add_line(f"Feature identifiée : layer='{layer_name}', id={fid}")
        except Exception as e:
            self.dock.add_line(f"Feature identifiée (erreur lecture): {e}")

    # --------------------
    # Événements de couches & sélection
    # --------------------
    def start_listening(self):
        """Connecte les signaux globaux du projet et des couches existantes."""
        # connexion aux changements de projet (couches ajoutées / supprimées)
        try:
            self.project.layersAdded.connect(self.on_layers_added)
            self.project.layersRemoved.connect(self.on_layers_removed)
            self.dock.add_line("Connecté aux signaux du projet (layersAdded, layersRemoved).")
        except Exception:
            # fallback/notification si la signature diffère selon version
            self.dock.add_line("Impossible de connecter certains signaux de QgsProject sur cette version.")
        # écouter les changements d'emprise (zoom/pan)
        try:
            self.canvas.extentsChanged.connect(self.on_extent_changed)
            self.dock.add_line("Connecté au signal extentsChanged (zoom/pan).")
        except Exception:
            self.dock.add_line("Impossible de connecter extentsChanged sur cette version.")

        # connexion au changement de couche active via iface (s'il existe)
        try:
            # QgisInterface expose souvent currentLayerChanged signal
            self.iface.currentLayerChanged.connect(self.on_current_layer_changed)
            self.dock.add_line("Connecté au signal currentLayerChanged.")
        except Exception:
            # alternative : layer tree view
            try:
                ltv = self.iface.layerTreeView()
                ltv.currentLayerChanged.connect(self.on_current_layer_changed)
                self.dock.add_line("Connecté au signal layerTreeView.currentLayerChanged.")
            except Exception:
                self.dock.add_line("Impossible de connecter le signal de changement de couche active.")

        # connecter les couches déjà présentes pour écouter les sélections
        for layer in list(self.project.mapLayers().values()):
            self._connect_layer_selection(layer)

    def stop_listening(self):
        """Déconnecte tous les signaux propres et réinitialise outils."""
        # déconnecter project signals
        try:
            self.project.layersAdded.disconnect(self.on_layers_added)
            self.project.layersRemoved.disconnect(self.on_layers_removed)
        except Exception:
            pass

        # déconnecter currentLayerChanged
        try:
            self.iface.currentLayerChanged.disconnect(self.on_current_layer_changed)
        except Exception:
            try:
                ltv = self.iface.layerTreeView()
                ltv.currentLayerChanged.disconnect(self.on_current_layer_changed)
            except Exception:
                pass
        try:
            self.canvas.extentsChanged.disconnect(self.on_extent_changed)
        except Exception:
            pass

        # déconnecter sélections par couche
        for layer_id, _ in list(self._layer_selection_connections.items()):
            layer = self.project.mapLayer(layer_id)
            if layer is None:
                continue
            try:
                layer.selectionChanged.disconnect(self._layer_selection_connections[layer_id])
            except Exception:
                # attempt generic disconnect (some PyQGIS versions don't return connection ids)
                try:
                    layer.selectionChanged.disconnect()
                except Exception:
                    pass
            finally:
                self._layer_selection_connections.pop(layer_id, None)

        # remettre outil par défaut de QGIS (outil de navigation)
        self.canvas.unsetMapTool(self.point_tool)
        self.canvas.unsetMapTool(self.identify_tool)
        self.dock.add_line("Tous les signaux déconnectés et outils remis.")

    def on_layers_added(self, layers):
        """Slot quand des couches sont ajoutées au projet (layers est une liste)."""
        # log et connecte la sélection pour chaque nouvelle couche
        names = [l.name() for l in layers]
        self.dock.add_line(f"Couches ajoutées : {', '.join(names)}")
        for layer in layers:
            self._connect_layer_selection(layer)

    def on_layers_removed(self, layer_ids):
        """Slot quand des couches sont supprimées (ids list)."""
        self.dock.add_line(f"Couches supprimées : {', '.join(map(str, layer_ids))}")
        # nettoyer nos enregistrements
        for lid in layer_ids:
            if lid in self._layer_selection_connections:
                self._layer_selection_connections.pop(lid, None)

    def on_current_layer_changed(self, layer):
        """Slot quand la couche active change (layer: QgsMapLayer)."""
        name = layer.name() if layer is not None else "Aucune"
        self.dock.add_line(f"Couche active changée -> {name}")
        # (optionnel) reconnecter sélection si besoin
        if layer is not None:
            self._connect_layer_selection(layer)

    def _connect_layer_selection(self, layer):
        """Connecte le signal selectionChanged d'une couche (si possible) pour logger les sélections."""
        try:
            if layer is None:
                return
            layer_id = layer.id()
            # ne pas connecter deux fois
            if layer_id in self._layer_selection_connections:
                return
            # selectionChanged signature: (QgsFeatureIds, QgsFeatureIds, QgsFeatureIds)
            def sel_changed(selected, deselected, clear_and_select):
                try:
                    cnt = len(selected)
                    self.dock.add_line(f"Sélection sur couche '{layer.name()}': {cnt} entité(és) sélectionnée(s). IDs: {list(selected)[:10]}")
                except Exception as e:
                    self.dock.add_line(f"Erreur handling selectionChanged: {e}")

            layer.selectionChanged.connect(sel_changed)
            # stocker l'objet function reference pour pouvoir déconnecter plus tard
            self._layer_selection_connections[layer_id] = sel_changed
            self.dock.add_line(f"Écoute sélection activée pour la couche '{layer.name()}'.")
        except Exception as e:
            self.dock.add_line(f"Impossible de connecter selectionChanged pour {getattr(layer, 'name', lambda: '?')()}: {e}")

    # --------------------
    # Nettoyage
    # --------------------
    def unload(self):
        """Appelé par QGIS quand le plugin est désactivé ; nettoyage."""
        # retirer action/menu
        try:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&EventListener", self.action)
        except Exception:
            pass

        # arrêter l'écoute proprement
        try:
            self.stop_listening()
        except Exception:
            pass

        # enlever le dock
        try:
            self.iface.removeDockWidget(self.dock)
        except Exception:
            pass
