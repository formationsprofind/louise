# __init__.py
def classFactory(iface):
    """Point d'entrée attendu par QGIS"""
    from .event_listener import EventListener
    return EventListener(iface)
